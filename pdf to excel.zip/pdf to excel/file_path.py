

file_path_of_pdf = r"C:\Users\MBSPL-Ayush\Desktop\Bihar\Bihar\GSTR3B_10AAHCB3756A1ZC_012023.pdf"