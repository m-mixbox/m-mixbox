
import docx 

wordDoc = docx.Document(r"D:\xamppnew\htdocs\scripts\python codes\writing_to_docx\SBI Format.docx")
d = {}
a= []
for table in wordDoc.tables:

    for row in table.rows:
        #for cell in row.cells:
            #print (cell.text)
        a= list(set([cell.text for cell in row.cells if cell.text != ""]))
        #print(len(a))
        #print(a)
        print(len([cell.text for cell in row.cells if cell.text != ""]))
        print([cell.text for cell in row.cells if cell.text != ""])
        if(len(a)>1):
            
            b = [cell.text for cell in row.cells].count(a[0])
            c = [cell.text for cell in row.cells].count(a[1])
            if(b==2 and c ==4):
                d[a[0]] = a[1]
            elif (b==4 and c ==2):
                d[a[1]] = a[0]
            if(len(a)>2):
                z = [i for i in a if i != "" and i.strip() != "Yes" and i != "No" and i.strip() != "DM" and i != "HTN" and i.strip() != "N/A" and i != "Other"]
                #print(a)
                #print([i for i in a if i != "" and i.strip() != "Yes" and i != "No" and i.strip() != "DM" and i != "HTN" and i.strip() != "N/A" and i != "Other"])
                d[z[0]] = [x for x in a if z[0] != x and x != "" ]
                #print([cell.text for cell in row.cells])
                #print([i for i in a if i != "" and i.strip() != "Yes" and i != "No" and i.strip() != "DM" and i != "HTN" and i.strip() != "N/A" and i != "Other"])
        #print(a[0],end='')
        #print(" occured : ",end='')
        #print(b,end='')
        #print(" times")
        #print(a[1],end='')
        #print(" occured : ",end='')
        #print(c,end='')
        #print(" times")
        print('--------------------')
    print('+++++++++++++++++')

#for key, value in d.items():
    #print(f"{key}: {value}")