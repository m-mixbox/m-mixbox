from turtle import width
from docx.shared import Inches
from docx import Document

# Open the existing Word document
doc = Document(r"D:\xamppnew\htdocs\scripts\python codes\writing_to_docx\SBI Format.docx")

# Access the first table (index 0)
table = doc.tables[0]
table_input_position = [5,5,5,5,5,5,5,5,5]
table_input_list = []
table_input_list_2 = []
# Add text to specific cells
for i in range(len(table.rows)):
    if(i<=8):
        table.cell(i, table_input_position[i]).text = "  hello"
    elif(i== 23):
        table.cell(i, 5).text = "  hello"

table_2 = doc.tables[1]
table_input_position_2 = [2,2,2]
row = table_2.rows
for i in range(len(table_2.rows)):
    #print([cell.text for cell in row[i].cells if cell.text != ""])
    if(i>=12 and i<15):
        table_2.cell(i, table_input_position_2[i-12]).text = "  hello"
    elif(i==16):
        table_2.cell(i, 2).text = "  hello"
    elif(i==18):
        table_2.cell(i, 2).text = "  hello"


table_3 = doc.tables[2]
for row in table_3.rows:
        for cell in row.cells:
            # Clear all paragraphs and runs
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.clear()
image_index = 0  # Track which image to add
start_row = 0
start_col =0
image_paths = [r"D:\xamppnew\htdocs\scripts\python codes\hugging_face_api\images\1E2KS.jpg",r"D:\xamppnew\htdocs\scripts\python codes\hugging_face_api\images\1X0I8.jpg",r"D:\xamppnew\htdocs\scripts\python codes\hugging_face_api\images\2A1VW.jpg",r"D:\xamppnew\htdocs\scripts\python codes\hugging_face_api\images\2GW4H.jpg"]
for row_idx in range(start_row, len(table_3.rows)):
        for col_idx in range(start_col, len(table_3.columns)):
            if image_index >= len(image_paths):
                break  # Stop if no more images to add
            
            # Get the cell and add the image
            cell = table_3.cell(row_idx, col_idx)
            paragraph = cell.paragraphs[0]  # Get the first paragraph in the cell
            run = paragraph.add_run()
            run.add_picture(image_paths[image_index],width=Inches(4.06))  # Adjust width as needed
            
            image_index += 1  # Move to the next image
        
        if image_index >= len(image_paths):
            break  # Stop if no more images to add
# Save the modified document
doc.save('modified_document_2.docx')

print("Text added to the existing table successfully!")
