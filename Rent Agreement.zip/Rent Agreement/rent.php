<?php

Echo"hello Ayush";
?>